from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Instr_1a(Page):
    pass


class Instr_1b(Page):
    pass


class Instr_2a(Page):
    form_model = 'player'
    form_fields = ['HL']  # the demo MPL


class Instr_2b(Page):
    form_model = 'player'
    form_fields = ['HL']  # the demo MPL

page_sequence = [ Instr_1a, Instr_1b, Instr_2a, Instr_2b]
